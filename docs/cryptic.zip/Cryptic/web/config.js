/* ============================================================
   Your GitHub repository URL. Every "Clone" / "View on GitHub"
   button and the git-clone command on the page reads from here.
   Change it if you ever move or rename the repo. Nothing else to edit.
   ============================================================ */
window.CRYPTIC_CONFIG = {
  repoUrl: "https://github.com/3nylar/Cryptic"
};
