# Cryptic — website

An interactive, beginner-friendly explainer for the Caesar and Vigenère ciphers,
with a **working code-breaker that runs entirely in the browser** (no server).
It defines each cipher in plain language, compares them, shows why they are
insecure, and lets visitors try the real tool live.

## Deploy it (pick one — all free)

This is a static site: just `index.html` and a few assets. Nothing to build.

### GitHub Pages (recommended, since the repo is already on GitHub)
The repo already ships this site under `web/`. Two ways to publish it:

**A. Serve the `web/` folder from a branch**
1. Push the repo to GitHub (already set: `https://github.com/3nylar/Cryptic`).
2. **Settings → Pages → Build and deployment → Source: “Deploy from a branch”.**
3. Branch: `main`, folder: `/web`. Save.
4. Live in ~1 minute at `https://3nylar.github.io/Cryptic/`.

**B. Or copy these files to the repo root** if you'd rather serve from `/`.

### Netlify / Vercel
Drag the `web/` folder onto the Netlify dashboard, or run `vercel` from inside it.

### Test locally first
```bash
cd web
python -m http.server 8000     # then open http://localhost:8000
```

## The one setting: your repo link

`config.js` already points at `https://github.com/3nylar/Cryptic`. Every
"Clone" / "View on GitHub" button and the `git clone` command read from it. Only
change it if you move or rename the repo:

```js
window.CRYPTIC_CONFIG = {
  repoUrl: "https://github.com/3nylar/Cryptic"
};
```

## Files

| File | What it is |
|---|---|
| `index.html` | The whole page (HTML + CSS inline) |
| `engine.js` | The ciphers + breakers, ported to JavaScript — this is what makes the terminal work |
| `app.js` | Page behaviour: the demos and the live terminal |
| `config.js` | Your repo URL |
| `Cryptic-source.zip` | The full Python project, for the "Download" button (optional — see below) |
| `.nojekyll` | Tells GitHub Pages to serve files as-is |

### About the download button
The "Download the .zip" button links to `Cryptic-source.zip`. If you want that
button to work, drop a zip of the Python project (without `.git`/`.venv`) next to
`index.html` with that name. If you'd rather not, delete the button — the
"View on GitHub" button already lets visitors get the code.

## How the in-browser tool works

The terminal is not a mock-up. `engine.js` is a faithful port of the Python
project's cipher and cryptanalysis code — Caesar and Vigenère encrypt/decrypt,
frequency analysis, index of coincidence, Kasiski examination, per-column
solving, and the bigram model. Everything runs on the visitor's device; nothing
is ever sent anywhere.
